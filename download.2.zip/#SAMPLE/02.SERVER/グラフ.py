#MODE=SERVER(ayax)
#import os 記載が不要になりました。2023/08/27
#os.environ['MPLCONFIGDIR'] = os.getcwd() + "/configs/"　記載が不要になりました。2023/08/27
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt

colors =["navy", "yellow", "blue", "gold", "red","tomato","green","Magenta"]
labels = ["A", "B", "C", "D", "E","F","G","H"]
data = [39, 17, 13, 12, 7,7,3,2]
plt.pie(data, labels=labels, colors=colors)
plt.axis("equal") 

#plt.show()
plt.savefig('ret.png') 

#クラウドファイル(ret.png)をダブルクリックしてください
#サポート形式 jpeg,jpg,png



