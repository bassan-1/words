#MODE=SERVER(ayax)
from bs4 import BeautifulSoup
from urllib import request

URL = 'https://pyweb.ayax.jp/'
response = request.urlopen(URL)
soup = BeautifulSoup(response,"html.parser")
response.close()

print(soup.title.text)